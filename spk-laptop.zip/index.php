<?php
include 'header.php';
?>

<body>
    <div class="navbar-fixed">
        <nav>
            <div class="container">
                <div class="nav-wrapper">
                    <ul class="left" style="margin-left: -52px;">
                        <li><a href="index.php">HOME</a></li>
                        <li><a href="daftar_laptop.php">DAFTAR LAPTOP</a></li>
                        <li><a href="login.php">LOGIN</a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </div> <!-- Jumbotron Start -->
    <div id="index-banner" class="parallax-container">
        <div class="section no-pad-bot">
            <div class="container">
                <h1 class="header jarak center white-text" style="font-size: 40px">SISTEM PENDUKUNG KEPUTUSAN PEMILIHAN LAPTOP
                    MENGGUNAKAN METODE WEIGHT PRODUCT (WP)</h1>
                <!-- <div class="row center">
                    <h5 class="header jarak-button col s12 light" style="margin-bottom: 0px; font-size: 26px">PEMILIHAN
                        LAPTOP</h5>
                </div> -->
                <div class="row center" \>
                    <a href="rekomendasi.php" id="download-button" class="waves-effect waves-light btn-large blue darken-1"
                        style="border-radius:20px; width: 230px; padding:0 15px; margin-top: 20px; color: #fff; font-weight: bold;">
                        Pilih Rekomendasi</a>
                </div>
            </div>
        </div>
        <div class="parallax"><img src="assets/image/laptop.png" alt="Laptop"></div>
    </div>
    <!-- Jumbotron End -->

    <!-- Info Start -->
    <div style="background-color: white">
        <div class="container">
            <div class="section-card" style="padding: 36px 0px">
                <div class="row">
                    <div class="col s6">
                        <center>
                            <h5 class="header"
                                style="margin-left: 0px; margin-bottom: 0px; margin-top: 25px; color: #635c73">INFO
                                SISTEM</h5>
                        </center><br>
                        <p style="text-align: justify; padding-right: 16px;">Sistem Pendukung Keputusan Pemilihan Laptop
                            Menggunakan
                            Metode WEight Product,Tech yang digunakan adalah PHP, HTML dan CSS. Sistem ini di gunakan
                            untuk Pemenuhan
                            Tugas Akhir Pada Universitas Muhammadiyah Ponorogo.
                        </p>
                    </div>
                    <div class="col s6">
                        <center>
                            <h5 class="header"
                                style="margin-left: 0px; margin-bottom: 0px; margin-top: 25px; color: #635c73">INFO
                                METODE</h5>
                        </center><br>
                        <p style="text-align: justify; padding-left: 16px;">Metode yang digunakan adalah metode Weight
                            Product (WP) Metode ini Memanfaatkan Kriteria setiap Laptop yang sudah diberikan Bobot.
                            Kemudian Metode
                            ini akan menghitung nilai dari setiap kriteria dan menghitung nilai dari setiap laptop.
                            Nilai dari setiap laptop
                            akan diurutkan Hasil tertinggi merupakan Rekomendasi Utama.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

<?php
    include 'footer.php';
?>