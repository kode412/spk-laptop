<!-- Footer Start -->
<div class="footer-copyright" style="padding: 0px 0px">
    <div class="container">
        <p align="center" style="color: #999">&copy; Sistem Pendukung Keputusan Pemilihan Laptop</p>
    </div>
</div>
<!-- Footer End -->

<script type="text/javascript">
$(document).ready(function() {
    $('.parallax').parallax();
    $('.modal').modal();
});
</script>

</html>