<?php 
include 'header.php';
?>

<body>
    <div class="navbar-fixed">
        <nav>
            <div class="container">
                <div class="nav-wrapper">
                    <ul class="left" style="margin-left: -52px;">
                        <li><a href="index.php">HOME</a></li>
                        <li><a href="daftar_laptop.php">DAFTAR LAPTOP</a></li>
                        <li><a href="login.php">LOGIN</a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </div>
    <div style="background-color: #efefef">
        <div class="container">
            <div class="section-card" style="padding: 5px 0px">
                <div class="row" style="margin-top:20px;">
                    <div class="card">
                        <div class="card-content">
                            <span class="card-title" style="color: #635c73; text-align: center; font-weight: bold;">
                                REKOMENDASI LAPTOP</span>
                            <p style=" text-align: center;">Silakan pilih spenggunaan yang sesuai, atau atur bobot
                                secara manual untuk mendapatkan rekomendasi laptop yang sesuai.</p>
                        </div>
                    </div>
                </div>
                <div class="row" style="display: flex; align-items: stretch;">
                    <div class="col s12">
                        <div class="card" style="margin-bottom: 10px;">
                            <div class="card-content">
                                <div class="row">
                                    <div class="col s12 m6"
                                        style="display: flex; flex-direction: column; justify-content: center;">
                                        <center>
                                            <h5 style="margin-bottom: 38px; fontt-weight: bold;">Pilih Penggunaan</h5>
                                        </center>
                                        <form action="hasil.php" method="post">
                                            <p style="margin-bottom:20px;">
                                                <input name="preset" type="radio" id="preset_gaming" value="gaming"
                                                    checked />
                                                <label for="preset_gaming">Untuk Gaming (Prioritas: Grafis VGA dan
                                                    RAM)</label>
                                            </p>
                                            <p style="margin-bottom:20px;">
                                                <input name="preset" type="radio" id="preset_kantor" value="kantor" />
                                                <label for="preset_kantor">Untuk Produktivitas Kantor
                                                    (Prioritas:Procesor dan RAM)</label>
                                            </p>
                                            <p style="margin-bottom:15px;">
                                                <input name="preset" type="radio" id="preset_desain" value="desain" />
                                                <label for="preset_desain">Untuk Desain Grafis / Video Editing
                                                    (Prioritas: VGA, RAM dan LCD)</label>
                                            </p>
                                            <p style="margin-bottom:30px;">
                                                <input name="preset" type="radio" id="preset_pelajar" value="pelajar" />
                                                <label for="preset_pelajar">Untuk Pelajar (Prioritas: Harga)</label>
                                            </p>
                                            <p style="margin-bottom:30px;">
                                                <input name="preset" type="radio" id="preset_umum" value="umum" />
                                                <label for="preset_umum">Umum / Seimbang (Prioritas: Seimbang)</label>
                                            </p>
                                            <div class="center-align" style="margin-top:24px; margin-bottom: 20px">
                                                <button class="btn waves-effect waves-light blue" type="submit"
                                                    name="action" style="border-radius:15px; padding:0 15px;">
                                                    Lihat Rekomendasi
                                                    <i class="material-icons right">send</i>
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="col s12 m6"
                                        style="display: flex; flex-direction: column; justify-content: center;">
                                        <center>
                                            <h5 style="margin-bottom:20px; ">Atur Bobot Manual</h5>
                                        </center>
                                        <form action="hasil.php" method="post">
                                            <div class="row" style="margin-bottom:10px;">
                                                <div class="col s12 "
                                                    style="display: flex; align-items: center; margin-bottom: 0px;">
                                                    <label for="harga_manual" style="flex:1; margin-left:20px;">Harga
                                                    </label>
                                                    <div class="col s6">
                                                        <select required name="harga" id="harga_manual"
                                                            style="width:220px; margin-left:10px;">
                                                            <option value="" disabled selected>Kriteria Harga</option>
                                                            <option value="5">&lt; Rp. 3.000.000</option>
                                                            <option value="4">3.000.000 - 7.000.000</option>
                                                            <option value="3">7.000.000 - 10.000.000</option>
                                                            <option value="2">10.000.000 - 15.000.000</option>
                                                            <option value="1">&gt; 10.000.000</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col s12"
                                                    style="display: flex; align-items: center; margin-bottom: 0px;">
                                                    <label for="processor_manual" style="flex:1; margin-left:20px;">Processor
                                                    </label>
                                                    <div class="col s6">
                                                        <select required name="harga" id="processor_manual"
                                                            style="width:220px; margin-left:12px;">
                                                            <option value="" disabled selected>Kriteria Processor
                                                            </option>
                                                            <option value="1">Gen < 4 </option>
                                                            <option value="2">Gen 4 - 7</option>
                                                            <option value="3">Gen 7 - 10</option>
                                                            <option value="4">Gen 10 - 12</option>
                                                            <option value="5"> > Gen 12</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col s12"
                                                    style="display: flex; align-items: center; margin-bottom: 0px;">
                                                    <label for="ram_manual" style="flex:1; margin-left:20px;">RAM
                                                    </label>
                                                    <div class="col s6">
                                                        <select required name="harga" id="ram_manual"
                                                            style="width:220px; margin-left:12px;">
                                                            <option value="" disabled selected>Kriteria RAM</option>
                                                            <option value="1">
                                                                < 2 Gb</option>
                                                            <option value="2"> 4 Gb</option>
                                                            <option value="3"> 8 Gb</option>
                                                            <option value="4"> 16 Gb</option>
                                                            <option value="5"> 32 Gb</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col s12"
                                                    style="display: flex; align-items: center; margin-bottom: 0px;">
                                                    <label for="vga_manual"
                                                        style="flex:1; margin-left:20px;">Grafis VGA
                                                    </label>
                                                    <div class="col s6">
                                                        <select required name="harga" id="vga_manual"
                                                            style="width:220px; margin-left:12px;">
                                                            <option value="" disabled selected>Kriteria VGA</option>
                                                            <option value="1"> UHD</option>
                                                            <option value="2"> 750 </option>
                                                            <option value="3"> 1059</option>
                                                            <option value="4"> 2050</option>
                                                            <option value="5"> 4090</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col s12"
                                                    style="display: flex; align-items: center; margin-bottom: 0px;">
                                                    <label for="memori_manual" style="flex:1; margin-left:20px;">Memory
                                                    </label>
                                                    <div class="col s6">
                                                        <select required name="harga" id="memori_manual"
                                                            style="width:220px; margin-left:12px;">
                                                            <option value="" disabled selected>Kriteria Memory</option>
                                                            <option value="1"> 128 Gb</option>
                                                            <option value="2"> 256 Gb</option>
                                                            <option value="3"> 512 Gb</option>
                                                            <option value="4"> 1024 Gb</option>
                                                            <option value="5"> 2048 Gb</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col s12"
                                                    style="display: flex; align-items: center; margin-bottom: 0px;">
                                                    <label for="lcd_manual" style="flex:1; margin-left:20px;">LCD
                                                    </label>
                                                    <div class="col s6">
                                                        <select required name="harga" id="lcd_manual"
                                                            style="width:220px; margin-left:12px;">
                                                            <option value="" disabled selected>Kriteria LCD</option>
                                                            <option value="1">11 Inch </option>
                                                            <option value="2">13 Inch </option>
                                                            <option value="3">14 Inch </option>
                                                            <option value="4">15 Inch </option>
                                                            <option value="5">16 Inch </option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="center-align" style="margin-top:15px;">
                                                <button class="btn waves-effect waves-light orange" type="submit"
                                                    name="action"
                                                    style="border-radius:24px; padding:0 15px; color: #000; font-weight: bold;">
                                                    Lihat Rekomendasi
                                                    <i class="material-icons right">send</i>
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script type="text/javascript">
    $(document).ready(function() {
        $('select').material_select();
    });
    </script>
</body>

<?php include 'footer.php'; ?>