<?php
echo password_hash('user123', PASSWORD_DEFAULT);
?>